using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Cattle_Log.Business.Services;
using Cattle_Log.Domain.Data.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static Cattle_Log.Pages.Receiving.ItemModel;

namespace Cattle_Log.Pages.Debrief
{
    [Authorize(Roles = "Debrief, Admin")]
    public class EnvelopeModel : PageModel
    {
        private readonly IEnvelopeService _envelopeRepo;
        private readonly IDepotService _depotRepo;
        private readonly IUserDepotService _userDepotRepo;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IItemService _itemRepo;
        private readonly IStatusService _statusRepo;

        public EnvelopeModel(IEnvelopeService envelopeRepo,
                          IDepotService depotRepo,
                          IItemService itemRep,
                          IStatusService statusRepo,
                          IUserDepotService userDepotRepo,
                          UserManager<IdentityUser> userManager)
        {
            _envelopeRepo = envelopeRepo;
            _depotRepo = depotRepo;
            _userDepotRepo = userDepotRepo;
            _userManager = userManager;
            _itemRepo = itemRep;
            _statusRepo = statusRepo;
        }

        [BindProperty]
        public EnvelopeViewModel Data { get; set; }

        public class EnvelopeViewModel
        {
            public Domain.Data.Entities.Envelope Envelope { get; set; }
            public List<Depot> Depots { get; set; }
            public List<Item> Items { get; set; }
            public List<Status> Status { get; set; }
        }

        public void OnGet(int? Id)
        {
            Data = new EnvelopeViewModel();

            if(Id != null)
            {
                Data.Envelope = _envelopeRepo.GetEnvelopeById(Id.GetValueOrDefault());
                Data.Items = _itemRepo.GetItemsByEnvelopeId(Data.Envelope.Id);
                Data.Status = _statusRepo.GetAllIStatusByEnvelopeId(Data.Envelope.Id);
            }
        }

        public async Task<RedirectToPageResult> OnPost()
        {
            var user = await _userManager.FindByNameAsync(User.Identity.Name);

            for (int i = 0; i < Data.Status.Count; i++)
            {
                var newStatus = new Status();
                newStatus.StatusUpdate = "Debriefed";
                newStatus.ItemId = Data.Status[i].ItemId;
                newStatus.EnvelopeId = Data.Status[i].EnvelopeId;
                newStatus.CreatedBy = user.UserName;
                newStatus.CreatedDate = DateTime.Now;
                await _statusRepo.AddStatus(newStatus);

                Data.Items[i].UpdatedBy = user.UserName;
                Data.Items[i].UpdatedDate = DateTime.Now;
                await _itemRepo.UpdateItem(Data.Items[i]);
            }

            Data.Envelope.Debriefed = true;
            await _envelopeRepo.UpdateEnvelope(Data.Envelope);

            return RedirectToPage("/Debrief/Index");
        }
    }
}