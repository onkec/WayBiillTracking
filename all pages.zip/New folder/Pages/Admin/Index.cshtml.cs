using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Cattle_Log.Business.Services;
using Cattle_Log.Domain.Data;
using Cattle_Log.Domain.Data.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace Cattle_Log.Pages.Admin
{
    [Authorize(Roles = "Admin")]
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IUserDepotService _userDepotService;
        private readonly IDepotService _depotService;
        private readonly UserManager<IdentityUser> _userManager;

        public IndexModel(ApplicationDbContext dbContext,
                          IUserDepotService userDepotService,
                          IDepotService depotService,
                          UserManager<IdentityUser> userManager)
        {
            _dbContext = dbContext;
            _userDepotService = userDepotService;
            _depotService = depotService;
            _userManager = userManager;
        }

        public List<AdminViewModel> Data {get; set;}
        public class AdminViewModel
        {
            public IdentityUser User { get; set; }
            public UserDepot UserDepot { get; set; }
            public Depot Depot { get; set; }
            public string Role { get; set; }
        }

        public async Task<IActionResult> OnGet()
        {
            var Users = _dbContext.Users.ToList();
            Data = new List<AdminViewModel>();

            if (Users.Count > 0)
            {
                var model = new AdminViewModel();

                foreach(var user in Users)
                {
                    model.User = user;
                    model.UserDepot = _userDepotService.GetUserDepotByUserId(model.User.Id);

                    if (model.UserDepot != null)
                    {
                        model.Depot = _depotService.GetDepotById(model.UserDepot.DepotId);
                    }

                    var roles = await _userManager.GetRolesAsync(model.User);

                    if (roles.Count > 0)
                    {
                        foreach (var role in roles)
                        {
                            if (role != "User")
                            {
                                model.Role = role;
                                break;
                            }
                        }
                    }

                    Data.Add(model);
                    model = new AdminViewModel();
                }
            }

            return Page();
        }
    }
}