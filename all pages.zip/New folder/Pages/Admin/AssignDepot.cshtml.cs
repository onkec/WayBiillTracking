using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Cattle_Log.Business.Services;
using Cattle_Log.Domain.Data;
using Cattle_Log.Domain.Data.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cattle_Log.Pages.Admin
{
    [Authorize(Roles = "Admin")]
    public class AssignDepotModel : PageModel
    {
        private readonly ApplicationDbContext _dbContext;
        private readonly IUserDepotService _userDepotService;
        private readonly IDepotService _depotService;

        public AssignDepotModel(ApplicationDbContext dbContext,
                                IUserDepotService userDepotService,
                                IDepotService depotService)
        {
            _dbContext = dbContext;
            _userDepotService = userDepotService;
            _depotService = depotService;
        }

        [BindProperty]
        public AssignDepotViewModel Data { get; set; }

        public class AssignDepotViewModel
        {
            public IdentityUser User { get; set; }
            public UserDepot UserDepot { get; set; }
            public List<Depot> Depots { get; set; }
        }

        public void OnGet(string id)
        {
            var User = _dbContext.Users.Where(x => x.Id == id)
                                        .FirstOrDefault();

            if (User != null)
            {
                Data = new AssignDepotViewModel();
                Data.User = User;
                Data.UserDepot = _userDepotService.GetUserDepotByUserId(Data.User.Id);

                if (Data.UserDepot == null)
                {
                    Data.UserDepot = new UserDepot();
                    Data.UserDepot.UserId = User.Id;
                }

                Data.Depots = _depotService.GetAllDepots();
            }
        }

        public async Task<RedirectToPageResult> OnPost()
        {
            var userDepot = new UserDepot();

            if(Data.UserDepot.Id == 0)
            {
                userDepot.UserId = Data.User.Id;
                userDepot.DepotId = Data.UserDepot.DepotId;

                await _userDepotService.AddUserDepot(userDepot);
            }
            else
            { 
                await _userDepotService.UpdateUserDepot(Data.UserDepot);
            }
            

            return RedirectToPage("/Admin/Index");
        }
    }
}