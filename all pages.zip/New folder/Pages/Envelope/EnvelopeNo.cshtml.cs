using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cattle_Log.Pages.Envelope 
{ 
[BindProperties]
public class EnvelopeNoModel : PageModel
{
    public int EnvelopeNo {  get; set; }
    public void OnGet(int id)
    {
        EnvelopeNo = id;
    }
}
}