using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Cattle_Log.Business.Services;
using Cattle_Log.Domain.Data;
using Cattle_Log.Domain.Data.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cattle_Log.Pages.Envelope
{
    [Authorize(Roles = "Send, Admin")]
    public class NewModel : PageModel
    {
        private readonly IDepotService _depotRepo;
        private readonly IEnvelopeService _envelopeRepo;
        private readonly IStatusService _statusRepo;
        private readonly IItemService _itemRepo;
        private readonly IUserDepotService _userDepotRepo;
        private readonly UserManager<IdentityUser> _userManager;

        public NewModel(IDepotService depotRepo,
                        IEnvelopeService envelopeRepo,
                        IStatusService statusRepo,
                        IItemService itemRepo,
                        IUserDepotService userDepotRepo,
                        UserManager<IdentityUser> userManager)
        {
            _depotRepo = depotRepo;
            _envelopeRepo = envelopeRepo;
            _statusRepo = statusRepo;
            _itemRepo = itemRepo;
            _userDepotRepo = userDepotRepo;
            _userManager = userManager;
        }

        [BindProperty]
        public Domain.Data.Entities.Envelope Envelope { get; set; }
        public List<Depot> Depots { get; set; }
        
        [BindProperty]
        public List<Item> Items { get; set; }
        public Status Status { get; set; }


        public async Task OnGet()
        {
            var user = await _userManager.FindByNameAsync(User.Identity.Name);
            var userDepot = _userDepotRepo.GetUserDepotByUserId(user.Id);
            var depots = _depotRepo.GetAllDepots();

            Depots = ExcludeMyDepot(userDepot, depots);
            Envelope = new Domain.Data.Entities.Envelope();
            Envelope.FromDepotId = userDepot.DepotId;
            Items = new List<Item>();
        }

        public async Task<RedirectToPageResult> OnPostAsync()
        {
            var user = await _userManager.FindByNameAsync(User.Identity.Name);
            Envelope.CreatedBy = user.UserName;
            Envelope.CreatedDate = DateTime.Now;
            await _envelopeRepo.AddEnvelope(Envelope);


            for (int i = 0; i < Items.Count; i++)
            {
                Status = new Status();
                Status.StatusUpdate = "Created";
                Status.EnvelopeId = Envelope.Id;
                Status.CreatedBy = user.UserName;
                Status.CreatedDate = DateTime.Now;
                await _statusRepo.AddStatus(Status);

                Items[i].EnvelopeId = Envelope.Id;
                Items[i].UpdatedBy = user.UserName;
                Items[i].UpdatedDate = DateTime.Now;
                await _itemRepo.AddItem(Items[i]);

                Status.ItemId = Items[i].Id;
                await _statusRepo.UpdateStatus(Status);
            }

            return RedirectToPage("/Sending/Index", new { id = Envelope.Id });
        }

        private List<Depot> ExcludeMyDepot(UserDepot userDepot, List<Depot> depots)
        {
            var depotList = new List<Depot>();

            foreach (var depot in depots)
            {
                if (depot.Id != userDepot.DepotId)
                {
                    depotList.Add(depot);
                }
            }

            return depotList;
        }
    }
}