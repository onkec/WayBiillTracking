using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Cattle_Log.Business.Services;
using Cattle_Log.Domain.Data;
using Cattle_Log.Domain.Data.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cattle_Log.Pages.Sending
{
    [Authorize(Roles = "Send, Admin")]
    public class IndexModel : PageModel
    {
        private readonly IEnvelopeService _envelopeRepo;
        private readonly IDepotService _depotRepo;
        private readonly IUserDepotService _userDepotRepo;
        private readonly UserManager<IdentityUser> _userManager;

        public IndexModel(IEnvelopeService envelopeRepo,
                          IDepotService depotRepo,
                          IUserDepotService userDepotRepo,
                          UserManager<IdentityUser> userManager)
        {
            _envelopeRepo = envelopeRepo;
            _depotRepo = depotRepo;
            _userDepotRepo = userDepotRepo;
            _userManager = userManager;
        }

        public List<IndexViewModel> Data { get; set; }

        public class IndexViewModel
        {
            public Domain.Data.Entities.Envelope Envelope { get; set; }
            public List<Depot> Depots { get; set; }
        }

        public async Task OnGet(int? id)
        {
            if(id != null)
            {
                ViewData["EnvelopeId"] = id;
            }

            var user = await _userManager.FindByNameAsync(User.Identity.Name);
            var userDepot = _userDepotRepo.GetUserDepotByUserId(user.Id);

            if (userDepot == null)
                userDepot = new UserDepot();

            var envelopes = _envelopeRepo.GetAllEnvelopesFromLocation(userDepot.DepotId);
            Data = new List<IndexViewModel>();

            if (envelopes.Any())
            {
                var model = new IndexViewModel();

                foreach (var envelope in envelopes)
                {
                    model.Envelope = envelope;
                    model.Depots = GetDepotDetails(envelope);

                    Data.Add(model);
                    model = new IndexViewModel();
                }
            }
        }

        private List<Depot> GetDepotDetails(Domain.Data.Entities.Envelope envelope)
        {
            var result = new List<Depot>();

            result.Add(_depotRepo.GetDepotById(envelope.FromDepotId));
            result.Add(_depotRepo.GetDepotById(envelope.ToDepotId));

            return result;
        }
    }
}