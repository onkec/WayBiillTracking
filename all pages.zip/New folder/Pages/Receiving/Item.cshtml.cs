using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Cattle_Log.Business.Services;
using Cattle_Log.Domain.Data.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cattle_Log.Pages.Receiving 
{
    [Authorize(Roles = "Receive, Admin")]
    public class ItemModel : PageModel
    {
        private readonly IItemService _itemRepo;
        private readonly IEnvelopeService _envelopeRepo;
        private readonly IStatusService _statusRepo;
        private readonly UserManager<IdentityUser> _userManager;

        public ItemModel(IEnvelopeService envelopeRepo, 
                         IItemService itemRep, 
                         IStatusService statusRepo,
                         UserManager<IdentityUser> userManager)
        {
            _envelopeRepo = envelopeRepo;
            _itemRepo = itemRep;
            _statusRepo = statusRepo;
            _userManager = userManager;
        }

        [BindProperty]       
        public ItemViewModel Data { get; set; }

        
        public class ItemViewModel
        {
            public Domain.Data.Entities.Envelope Envelope { get; set; }
            public List<Item> Items { get; set; }
            public List<Status> Status { get; set; }
        }
        
        public void OnGet(int id)
        {
            Data = new ItemViewModel();
            Data.Envelope = _envelopeRepo.GetEnvelopeById(id);
            Data.Items = _itemRepo.GetItemsByEnvelopeId(Data.Envelope.Id);
            Data.Status = _statusRepo.GetAllIStatusByEnvelopeId(Data.Envelope.Id);
        }
        
        public async Task<RedirectToPageResult> OnPost(int[] statusUpdate)
        {
            var user = await _userManager.FindByNameAsync(User.Identity.Name);

            for(int i = 0; i < Data.Status.Count; i++)
            {
                var hasArrived = CheckIfIdReturned(Data.Status[i].ItemId, statusUpdate);

                if(hasArrived)
                {
                    var newStatus = new Status();
                    newStatus.StatusUpdate = "Arrived";
                    newStatus.ItemId = Data.Status[i].ItemId;
                    newStatus.EnvelopeId = Data.Status[i].EnvelopeId;
                    newStatus.CreatedBy = user.UserName;
                    newStatus.CreatedDate = DateTime.Now;
                    await _statusRepo.AddStatus(newStatus);

                    Data.Items[i].UpdatedBy = user.UserName;
                    Data.Items[i].UpdatedDate = DateTime.Now;
                    await _itemRepo.UpdateItem(Data.Items[i]);
                }
                else
                {
                    var newStatus = new Status();
                    newStatus.StatusUpdate = "Missing";
                    newStatus.ItemId = Data.Status[i].ItemId;
                    newStatus.EnvelopeId = Data.Status[i].EnvelopeId;
                    newStatus.CreatedBy = user.UserName;
                    newStatus.CreatedDate = DateTime.Now;
                    await _statusRepo.AddStatus(newStatus);

                    Data.Items[i].UpdatedBy = user.UserName;
                    Data.Items[i].UpdatedDate = DateTime.Now;
                    await _itemRepo.UpdateItem(Data.Items[i]);
                }
            }

            Data.Envelope.Recieved = true;
            await _envelopeRepo.UpdateEnvelope(Data.Envelope);

            return RedirectToPage("/Receiving/Index");
        }

        private bool CheckIfIdReturned(int id, int[] statusUpdate)
        {
            bool hasReturned = false;

            foreach (var stat in statusUpdate)
            {
                if(id == stat)
                {
                    hasReturned = true;
                    break;
                }
            }
            
            return hasReturned;
        }
    }
}