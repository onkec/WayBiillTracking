using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cattle_Log.Areas.Identity.Pages.Account.Manage
{
    public class UserDetailsModel : PageModel
    {
        private readonly UserManager<IdentityUser> _userManager;

        public UserDetailsModel(UserManager<IdentityUser> userManager)
        {
            _userManager = userManager;
        }

        [BindProperty]
        public IdentityUser User { get; set; }

        public async Task OnGet(string id)
        {
            User = await _userManager.FindByIdAsync(id);

            ViewData["userRoles"] = await _userManager.GetRolesAsync(User);
        }
    }
}