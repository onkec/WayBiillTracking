using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Cattle_Log.Domain.Data.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Cattle_Log.Areas.Identity.Pages.Account.Manage
{
    public class UserEditModel : PageModel
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public UserEditModel(UserManager<IdentityUser> userManager,
                             RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        [BindProperty]
        public IdentityUser User { get; set; }
        
        public async Task OnGet(string id)
        {
            User = await _userManager.FindByIdAsync(id);

            ViewData["roleList"] = _roleManager.Roles.ToList();
            ViewData["userRoles"] = await _userManager.GetRolesAsync(User);
        }

        public async Task<RedirectToPageResult> OnPost(List<string> roles)
        {
            var user = await _userManager.FindByIdAsync(User.Id);
            var userRoles = await _userManager.GetRolesAsync(user);
            await RoleChanger(user, userRoles, roles);

            
            return RedirectToPage("Users");
        }

        private async Task RoleChanger(IdentityUser user, IList<string> current, List<string> update)
        {
            List<string> tempCurr = new List<string>(current);
            List<string> tempUpdt = new List<string>(update);

            if (tempCurr.Count == 0 && tempUpdt.Count == 0)
            {
                // Apply no change
            }
            else if (tempCurr.Count == 0 && tempUpdt.Count != 0)
            {
                foreach (var role in update)
                {
                    await _userManager.AddToRoleAsync(user, role);
                }
            }
            else if (tempCurr.Count != 0 && tempUpdt.Count == 0)
            {
                foreach (var currRole in current.ToList())
                {
                    await _userManager.RemoveFromRoleAsync(user, currRole);
                }
            }
            else if (tempCurr.Count != 0 && tempUpdt.Count != 0)
            {
                // Subtract update from current
                foreach (var currRole in tempCurr.ToList())
                {
                    foreach (var updRole in tempUpdt.ToList())
                    {
                        if (currRole == updRole)
                        {
                            tempCurr.Remove(currRole);
                            tempUpdt.Remove(updRole);
                        }
                    }
                }

                if (tempCurr.Count == 0 && tempUpdt.Count == 0)
                {
                    // Apply no change
                }
                else
                {
                    foreach (var curr in tempCurr.ToList())
                    {
                        await _userManager.RemoveFromRoleAsync(user, curr);
                    }
                    foreach (var role in tempUpdt.ToList())
                    {
                        await _userManager.AddToRoleAsync(user, role);
                    }
                }
            }
        }
    }
}