using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using Microsoft.EntityFrameworkCore;
using Cattle_Log.Domain.Data;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace Cattle_Log.Areas.Identity.Pages.Account.Manage
{
    [Authorize(Roles = "Admin")]
    public class UsersModel : PageModel
    {
        private readonly ApplicationDbContext _dbContext;

        public UsersModel(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<IdentityUser> Users { get; set; }
        public void OnGet()
        {
            Users = _dbContext.Users.ToList();
        }
    }
}