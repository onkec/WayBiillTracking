﻿var attachLimit = 10;
function AddNewItem() {
    var i = $(".newItem").length;

    var newItem = '<tr id="envelopeItem.' + i + '" class="newItem">' +
                        '<td>' +
                            '<div class="form-group">' +
                                '<input type="text" Id="Items[' + i + '].Description" name="Items[' + i + '].Description" class="form-control" required />' +
                                '<span asp-validation-for="ItemsDescription.' + i + '" class="text-danger"></span>' +
                            '</div>' +
                        '</td>' +
                        '<td>' +
                            '<div class="form-group">' +
                                '<input type="text" Id="Items[' + i + '].OtdWaybill" name="Items[' + i + '].OtdWaybill" class="form-control" required />' +
                                '<span asp-validation-for="ItemsOtdWaybill.' + i + '" class="text-danger"></span>' +
                            '</div>' +
                        '</td>' +
                        '<td>' +
                            '<div class="form-group">' +
                                '<input type="text" Id="Items[' + i + '].SendNote" name="Items[' + i + '].SendNote" class="form-control" required />' +
                                '<span asp-validation-for="ItemsSendNote.' + i + '" class="text-danger"></span>' +
                            '</div>' +
                        '</td>' +
                        '<td>' +
                            '<h4 class="iteration1"></h4><a href="#" onclick="RemoveAttach(' + i + ')" class="norecip"></a><br>' +
                        '</td>' +
                    '</tr>';

    $("#itemGroup").append(newItem);
    event.preventDefault();
    FormFieldsTextChange();
}

function FormFieldsTextChange() {
    $(".norecip").html("-");
}

function RemoveAttach(itemId) {
    var elem = document.getElementById("envelopeItem." + itemId);
    elem.remove();
    event.preventDefault();
}

function CheckIfItemsAdded()
{
    var i = $(".newItem").length;
    var flag = true;

    if (i <= 0)
    {
        flag = false;
        //Cannot create an envelope with no items
    }
    else
    {
        flag = ValidateFieldInputs(i);
    }

    if (flag == true)
    {
        $("form").submit();
    }
}

function ValidateFieldInputs(count)
{
    var flag = true;

    for (var i = 0; i < count; i++)
    {
        var val1 = document.getElementById('Items[' + i + '].Description').value
          , val2 = document.getElementById('Items[' + i + '].OtdWaybill').value;


        if (val1 == "" || val2 == "")
        {
            flag = false;
            break;
        }
    }

    return flag;
}