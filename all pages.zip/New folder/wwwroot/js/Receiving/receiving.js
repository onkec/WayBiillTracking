function UpdateText(val, id)
{
    document.getElementById('iSpan.' + id).remove();

    let span = document.createElement('span');
    span.id = 'iSpan.' + id + '';
    
    if (val.checked == true)
    {
        let text = document.createTextNode("Arrived");
        span.appendChild(text);
    }
    else
    {
        let text = document.createTextNode("Missing");
        span.appendChild(text);
    }

    document.getElementById('oLabel.' + id + '').appendChild(span);
}